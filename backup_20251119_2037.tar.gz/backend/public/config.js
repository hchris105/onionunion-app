window.API_BASE = "";            // 與 API 同網域就留空
window.API_TIMEOUT_MS = 135000;  // 135s

